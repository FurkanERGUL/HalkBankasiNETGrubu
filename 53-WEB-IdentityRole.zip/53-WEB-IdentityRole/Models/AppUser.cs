﻿using Microsoft.AspNetCore.Identity;

namespace _53_WEB_IdentityRole.Models
{
    public class AppUser : IdentityUser
    {

    }
}
