﻿namespace _53_WEB_IdentityRole.Models.VMs
{
    public class LogInVM
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
