﻿namespace _53_WEB_IdentityRole.Models.VMs
{
    public class RoleListVM
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string NormalizedName { get; set; }

    }
}
