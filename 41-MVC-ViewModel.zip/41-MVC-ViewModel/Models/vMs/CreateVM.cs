﻿namespace _41_MVC_ViewModel.Models.vMs
{
    public class CreateVM
    {
        public Personel Personel { get; set; }
        public List<Department> Departments { get; set; }

    }
}
