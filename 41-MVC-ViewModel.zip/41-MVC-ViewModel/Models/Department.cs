﻿namespace _41_MVC_ViewModel.Models
{
    public class Department
    {
        public int ID { get; set; }
        public string Name { get; set; }

    }
}
